#ifndef EJERCICIO_08_H_INCLUDED
#define EJERCICIO_08_H_INCLUDED

int leerLado();

bool esEscaleno(int lado_1, int lado_2, int lado_3);

bool esIsoceles(int lado_1, int lado_2, int lado_3);

bool esEquilatero(int lado_1, int lado_2, int lado_3);

#endif // EJERCICIO_08_H_INCLUDED
