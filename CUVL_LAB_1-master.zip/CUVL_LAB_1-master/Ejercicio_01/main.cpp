#include <iostream>

using namespace std;

/**
 * Ej. MI-1 Dados dos valores enteros A y B, informar la suma, la resta y el producto.
 */
int main()
{
    int numero_1 = 0;
    int numero_2 = 0;

    cout << "Ingrese el primer numero: " << endl;
    cin >> numero_1;
    cout << "Ingrese un segundo numero: " << endl;
    cin >> numero_2;
    cout << "La suma de los numeros es: " << numero_1 + numero_2 << endl;

    return 0;
}
